# Week 1 - 👁 C what you did there

1. Be inspired by Vitaly Friedman.
2. Pick an assignment
3. Understand your CSS methodology
4. Read and explain articles
5. Work!

## Tuesday

Hi!

### Inspirational introduction: “Let’s Break The Web!”

Bring a sketch book. Take (sketch)notes!

### Explaining the assignments

[All you need to know about the assignments can be found here](the-assignments.md)

### Sketching

Did we say you should bring a sketch book?

### Daily standup

What did you learn? What’s your plan? Where are the challenges?

## Thursday

**!important:** We start with [The Weekly Specificity](weekly-specificity.md). Read your articles, be on time!

The rest of the day:

- Work
- Daily standup

## Friday

- Feedback, conversations